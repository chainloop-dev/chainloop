# Security Policy

## Supported Versions

Chainloop releases is in a pre-1.0 state, we commit to add security patches to latest versions.

## Reporting a Vulnerability

To report a vulnerability, feel free to contain security@chainloop.dev or create an issue in this repository.
